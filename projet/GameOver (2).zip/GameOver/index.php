<?php
  session_start();
?>

<html>

  <head>
    <title>Accueil</title>
    <meta charset="utf-8"/>
    <link rel="stylesheet" href="style.css" />
  </head>

  <body>

    <?php include "menuhaut.php"; ?>

  </body>

</html>

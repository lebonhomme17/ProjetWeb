<?php
	$db = '';
	$conn = oci_connect("antoine", "azerty", $db);
?>